from django.contrib import admin
from labs.models import Labs
# Register your models here.
admin.site.register(Labs)
