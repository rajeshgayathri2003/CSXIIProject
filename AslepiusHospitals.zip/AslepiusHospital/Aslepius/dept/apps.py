from django.apps import AppConfig


class DeptConfig(AppConfig):
    name = 'dept'
