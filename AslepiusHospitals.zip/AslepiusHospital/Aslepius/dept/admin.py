from django.contrib import admin
'''from dept.models import Departments

admin.site.register(Departments)
'''
# Register your models here.
