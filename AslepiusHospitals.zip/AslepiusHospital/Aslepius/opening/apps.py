from django.apps import AppConfig


class OpeningConfig(AppConfig):
    name = 'opening'
