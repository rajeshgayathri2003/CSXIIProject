from django.contrib import admin
from login.models import Register

admin.site.register(Register)
# Register your models here.
