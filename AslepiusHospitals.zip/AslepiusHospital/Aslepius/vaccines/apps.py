from django.apps import AppConfig


class VaccinesConfig(AppConfig):
    name = 'vaccines'
