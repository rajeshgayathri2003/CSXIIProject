from django.shortcuts import render
def vaccines(request):
    return render(request,'vaccines/vaccines.html')
# Create your views here.
