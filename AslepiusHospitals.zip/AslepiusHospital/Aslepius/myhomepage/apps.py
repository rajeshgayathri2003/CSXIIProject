from django.apps import AppConfig


class MyhomepageConfig(AppConfig):
    name = 'myhomepage'
